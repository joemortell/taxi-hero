<?php
/*
Template Name: Test Page
*/
?>

<?php get_header(); ?>
	<div id="content">	

	</div> <!-- End Page Content -->
<?php get_footer(); ?>